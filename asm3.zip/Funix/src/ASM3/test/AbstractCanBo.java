package ASM3.test;

import java.io.Serializable;
import java.util.Comparator;

public abstract class AbstractCanBo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String hoTen;
	private int heSoLuong;
	private int phuCap;

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public int getHeSoLuong() {
		return heSoLuong;
	}

	public void setHeSoLuong(int heSoLuong) {
		this.heSoLuong = heSoLuong;
	}

	public int getPhuCap() {
		return phuCap;
	}

	public void setPhuCap(int phuCap) {
		this.phuCap = phuCap;
	}

	public abstract void nhapTT();

	public abstract long TinhLuong();

	public abstract void Display();

	public static Comparator<AbstractCanBo> compare = new Comparator<AbstractCanBo>() {
		public int compare(AbstractCanBo o1, AbstractCanBo o2) {
			if (o1.getHoTen().compareTo(o2.getHoTen()) == 0) {
				return o1.getHoTen().compareTo(o2.getHoTen());
			} else {
				return o1.getHoTen().compareTo(o2.getHoTen());
			}
		}
	};
}
