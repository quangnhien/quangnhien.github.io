package ASM3.test;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;

import java.util.Scanner;

public class Main {
	static ArrayList<AbstractCanBo> StaffList = new ArrayList<AbstractCanBo>();

	// tao ra mang StaffList bang cach input du lieu vao

	static void genStaff() {
		try {
			StaffList = Int.docList("staff.data");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	// save data vao file "staff.data"
	static void saveData() {
		try {
			Out.ghiList(StaffList, "staff.data");
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Save successful");
	}
	// Them staff vao mang 
	static void addStaff() {
		System.out.print("Do you want to creat a Staff or a Teacher (enter S for Staff, otherwise for Teacher)? ");
		Scanner scan = new Scanner(System.in);
		AbstractCanBo x;
		switch (scan.nextLine()) {
		case "s":
			x = new NhanVienHanhChinh();
			x.nhapTT();
			StaffList.add(x);
			break;

		default:
			x = new GiangVien();
			x.nhapTT();
			StaffList.add(x);
			break;
		}

	}
	// chinh sua thong tin nhan vien
	static void fixStaff() {
		System.out.print("Enter name of the Staff you want to fix: ");
		Scanner scan = new Scanner(System.in);
		String n = scan.nextLine();

		for (AbstractCanBo x : StaffList) {
			if (x.getHoTen().contains(n)) {
				x.Display();
				System.out.println("Enter new infomation of " + x.getHoTen());
				x.nhapTT();

			}
		}

	}
	//Hien thi thong tin nhan vien
	static void display_All() {
		System.out.format("| %10s", "Name");
		System.out.format("| %10s", "Fac/Dept");
		System.out.format("| %10s", "Deg/Pos");
		System.out.format("| %10s", "Sal Ratio");
		System.out.format("| %10s", "Allowance");
		System.out.format("| %15s", "T.Hours/W.days");
		System.out.format("| %10s%n", "Salary");
		Collections.sort(StaffList, AbstractCanBo.compare);
		for (AbstractCanBo x : StaffList) {
			x.Display();
		}
	}
	//Tim kiem nhan vien theo ten
	static void searchName() {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter name to search: ");
		String n = scan.nextLine();
		for (AbstractCanBo x : StaffList) {
			if (x.getHoTen().contains(n)) {
				x.Display();
			}
		}
	}
	//Tim kiem nhan vien theo phong/ban
	static void searchDep_Fac() {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter dep/fac to search: ");
		String n = scan.nextLine();
		for (AbstractCanBo x : StaffList) {
			if (x instanceof GiangVien) {
				if (((GiangVien) x).getKhoa().contains(n)) {
					x.Display();
				}
			} else {
				if (((NhanVienHanhChinh) x).getPhongBan().contains(n)) {
					x.Display();
				}
			}
		}
	}
	// Tao menu, giao dien cho nguoi dung
	static void makeMenu() {
		int n;
		Scanner scan = new Scanner(System.in);

		do {
			System.out.println("University Staff Management 1.0");
			System.out.println("		1- Add staff");
			System.out.println("		2- Search staff by name");
			System.out.println("		3- Search staff by department/facculty");
			System.out.println("		4- Fix staff");
			System.out.println("		5- Display all staff");
			System.out.println("		6- Exit");
			System.out.print("Select function (1, 2, 3, 4, 5 or 6): ");

			n = scan.nextInt();
			switch (n) {
			case 1:
				addStaff();
				break;
			case 2:
				searchName();
				break;
			case 3:
				searchDep_Fac();
				break;
			case 4:
				display_All();
				break;
			case 5:
				fixStaff();
				break;
			}
		} while (n < 6);

		System.out.println("----Exit----");
		scan.close();
	}

	public static void main(String[] args) {
		genStaff();// Input mang Staff tu file
		makeMenu();
		saveData();// Save data
	}
}
