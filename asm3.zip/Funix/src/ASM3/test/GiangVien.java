package ASM3.test;

import java.util.Scanner;

public class GiangVien extends AbstractCanBo {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String khoa;
	private String trinhDo;
	private int soTietDay;

	public String getKhoa() {
		return khoa;
	}

	public void setKhoa(String khoa) {
		this.khoa = khoa;
	}

	public String getTrinhDo() {
		return trinhDo;
	}

	public void setTrinhDo(String trinhDo) {
		this.trinhDo = trinhDo;
	}

	public int getSoTietDay() {
		return soTietDay;
	}

	public void setSoTietDay(int soTietDay) {
		this.soTietDay = soTietDay;
	}

	public void nhapTT() {
		Scanner scan = new Scanner(System.in);
		System.out.print("Name: ");
		super.setHoTen(scan.nextLine());

		System.out.print("Faculty: ");
		this.setKhoa(scan.nextLine());

		System.out.print("Salary ratio: ");
		super.setHeSoLuong(scan.nextInt());

		System.out.print("Degree (1 = BANCHELOR; 2 = MASTER; 3 = DOCTOR): ");
		switch (scan.nextInt()) {
		case 1:
			trinhDo = "BANCHELOR";
			super.setPhuCap(300);
			break;
		case 2:
			trinhDo = "MASTER";
			super.setPhuCap(500);
			break;
		default:
			trinhDo = "DOCTOR";
			super.setPhuCap(1000);
			break;
		}
		System.out.print("Number of teaching hours: ");
		this.setSoTietDay(scan.nextInt());
	}

	public long TinhLuong() {
		return (super.getHeSoLuong() * 730 + super.getPhuCap() + this.soTietDay * 45);
	}

	public void Display() {
		System.out.format("| %10s", getHoTen());
		System.out.format("| %10s", khoa);
		System.out.format("| %10s", trinhDo);
		System.out.format("| %10d", getHeSoLuong());
		System.out.format("| %10d", getPhuCap());
		System.out.format("| %15d", soTietDay);
		System.out.format("| %10d%n", TinhLuong());
	}

}
