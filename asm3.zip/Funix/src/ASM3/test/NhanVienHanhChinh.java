package ASM3.test;

import java.util.Scanner;

public class NhanVienHanhChinh extends AbstractCanBo {
	private String phongBan;
	private String chucVu;
	private int soNgayCong;

	public String getPhongBan() {
		return phongBan;
	}

	public void setPhongBan(String phongBan) {
		this.phongBan = phongBan;
	}

	public String getChucVu() {
		return chucVu;
	}

	public void setChucVu(String chucVu) {
		this.chucVu = chucVu;
	}

	public int getSoNgayCong() {
		return soNgayCong;
	}

	public void setSoNgayCong(int soNgayCong) {
		this.soNgayCong = soNgayCong;
	}

	public void nhapTT() {
		Scanner scan = new Scanner(System.in);
		System.out.print("Name: ");
		super.setHoTen(scan.nextLine());

		System.out.print("Department: ");
		this.setPhongBan(scan.nextLine());

		System.out.print("Salary ratio: ");
		super.setHeSoLuong(scan.nextInt());

		System.out.print("Position (1 = HEAD; 2 = VICE HEAD; 3 = STAFF): ");
		switch (scan.nextInt()) {
		case 1:
			chucVu = "HEAD";
			super.setPhuCap(2000);
			break;
		case 2:
			chucVu = "VICE HEAD";
			super.setPhuCap(1000);
			break;
		default:
			chucVu = "STAFF";
			super.setPhuCap(500);
			break;
		}
		System.out.print("Number of working days: ");
		soNgayCong = scan.nextInt();
	}

	public long TinhLuong() {
		return (super.getHeSoLuong() * 730 + super.getPhuCap() + soNgayCong * 45);
	}

	public void Display() {
		System.out.format("| %10s", getHoTen());
		System.out.format("| %10s", phongBan);
		System.out.format("| %10s", chucVu);
		System.out.format("| %10d", getHeSoLuong());
		System.out.format("| %10d", getPhuCap());
		System.out.format("| %15d", soNgayCong);
		System.out.format("| %10d%n", TinhLuong());
	}
}
