package ASM3.test;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

// ghi du lieu
public class Out {

	public static void ghiList(ArrayList<AbstractCanBo> x, String file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(x);
		oos.close();
	}

}