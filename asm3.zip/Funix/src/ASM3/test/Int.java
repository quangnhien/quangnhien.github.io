package ASM3.test;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

//doc du lieu
public class Int {

	public static ArrayList<AbstractCanBo> docList(String file) throws IOException, ClassNotFoundException {

		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream ois = new ObjectInputStream(fis);
		ArrayList<AbstractCanBo> StaffList = (ArrayList<AbstractCanBo>) ois.readObject();
		return StaffList;
	}
}